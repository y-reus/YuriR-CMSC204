package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface{

	private CourseDBStructure dbStructure;
	
	public CourseDBManager() {
		
		dbStructure = new CourseDBStructure(64);
	}
	
	@Override
	public void add(String CourseID, int CRN, int credits, String roomNum, String instructorName) {
		
		CourseDBElement element = new CourseDBElement(CourseID, CRN, credits, roomNum, instructorName);
		
		dbStructure.add(element);
	}

	@Override
	public CourseDBElement get(int crn) {
		
		try {
			
			return dbStructure.get(crn);
		} catch(IOException e) {
			
			System.out.println("Error");
			return null;
		}
	}

	@Override
	public void readFile(File input) throws FileNotFoundException {
		
		Scanner scanner = new Scanner(input);
		
		while (scanner.hasNextLine()) {
			
			String line = scanner.nextLine().trim();
			String[] p = line.split(" ");
			
			if (p.length >= 5) {
				
				String courseID = p[0];
				int crn = Integer.parseInt(p[1]);
				int credits = Integer.parseInt(p[2]);
				String roomNum = p[3];
				String instructorName = String.join(" ", java.util.Arrays.copyOfRange(p, 4, p.length));
				
				CourseDBElement element = new CourseDBElement(courseID, crn, credits, roomNum, instructorName);
				dbStructure.add(element);
			} else {
				
				System.out.println("invalid");
			}
		}
		
		scanner.close();
	}

	@Override
	public ArrayList<String> showAll() {
		
		return dbStructure.showAll();
	}

}
