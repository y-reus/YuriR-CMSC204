package application;

public class CourseDBElement implements Comparable<CourseDBElement> {

	private String courseID;
	private int crn;
	private int credits;
	private String roomNum;
	private String instructorName;

	public CourseDBElement() {

		this.courseID = "";
		this.crn = 0;
		this.credits = 0;
		this.roomNum = "";
		this.instructorName = "";
	}

	public CourseDBElement(String courseID, int crn, int credits, String roomNum, String instructorName) {

		this.courseID = courseID;
		this.crn = crn;
		this.credits = credits;
		this.roomNum = roomNum;
		this.instructorName = instructorName;
	}

	public String getCourseID() {

		return courseID;
	}

	public void setCourseID(String courseID) {

		this.courseID = courseID;
	}

	public int getCRN() {

		return crn;
	}

	public void setCRN(int crn) {

		this.crn = crn;
	}

	public int getCredits() {

		return credits;
	}

	public void setCredit(int credits) {

		this.credits = credits;
	}

	public String getRoomNum() {

		return roomNum;
	}

	public void setRoomNum(String roomNum) {

		this.roomNum = roomNum;
	}

	public String getInstructorName() {

		return instructorName;
	}

	public void setInstructorName(String instructorName) {

		this.instructorName = instructorName;
	}

	@Override
	public int compareTo(CourseDBElement o) {

		return Integer.compare(this.crn, o.crn);
	}

	@Override
	public String toString() {

		return String.format("\nCourse:%s CRN:%d Credits:%d Instructor:%s Room:%s", courseID, crn, credits,
				instructorName, roomNum);
	}
}
