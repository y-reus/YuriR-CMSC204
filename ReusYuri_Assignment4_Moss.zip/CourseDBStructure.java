package application;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

public class CourseDBStructure implements CourseDBStructureInterface{

	private LinkedList<CourseDBElement>[] hashTable;
	private int size;
	
	@SuppressWarnings("unchecked")
	public CourseDBStructure(int n) {
		
		int l = (int) Math.ceil(n / 1.5); // rounds up to nearest integer
		
		size = nextPrime(l); // finds next prime number after dividing load factor
		
		hashTable = new LinkedList[size];
		
		for (int i = 0; i < size; i++) { // Initializes each bucket as empty linked lists
			
			hashTable[i] = new LinkedList<>();
		}
	}
	
	@SuppressWarnings("unchecked")
	public CourseDBStructure(String test, int size) {
		
		this.size = size;
		
		hashTable = new LinkedList[size];
		
		for (int i = 0; i < size; i++) { // Initializes each bucket as empty linked lists
			
			hashTable[i] = new LinkedList<>();
		}
	}
	
	@Override
	public void add(CourseDBElement element) {
		
		int hashCode = getHashCode(element.getCRN());
		
		LinkedList<CourseDBElement> bucket = hashTable[hashCode];
		
		for (CourseDBElement e : bucket) { 
			
			if (e.getCRN() == element.getCRN()) { //removes and updates element that already exists in bucket
				
				bucket.remove(e);
				bucket.add(element);
				return;
			}
		}
		
		bucket.add(element);
	}

	@Override
	public CourseDBElement get(int crn) throws IOException {
		
		int hashCode = getHashCode(crn);
		
		LinkedList<CourseDBElement> bucket = hashTable[hashCode];
		
		for (CourseDBElement element: bucket) {
			
			if (element.getCRN() == crn) { // find element in bucket with the CRN and return it
				
				return element;
			}
		}
		
		throw new IOException("Not found");
	}

	@Override
	public ArrayList<String> showAll() {
		
		ArrayList<String> all = new ArrayList<>();
		
		for (int i = 0; i < size; i++) {
			
			LinkedList<CourseDBElement> bucket = hashTable[i]; // gets current bucket
			
			for (CourseDBElement element : bucket) {
				
				all.add(element.toString()); // adds string of each element
			}
		}
		
		return all;
	}

	@Override
	public int getTableSize() {
		
		return size;
	}
	
	private int getHashCode(int crn){
		
		return crn % size;
	}
	
	private int nextPrime(int num) {
		
		while(true) {
			
			if(isPrime(num)) { // returns the next prime number
				
				return num;
			}
			
			num++;
		}
	}
	
	private boolean isPrime(int num) {
		
		if (num <= 1) { // numbers less than or equal to 1 are not prime
			
			return false;
		}
		
		if (num == 2) { // 2 is prime
			
			return true;
		}
		
		if (num % 2 == 0) { // even numbers after 2 are not prime
			
			return false;
		}
		
		for (int i = 3; i <= Math.sqrt(num); i+= 2) { // see if it is divisible by 3 all the way till square root
			
			if (num % i == 0) {
				
				return false;
			}
		}
		
		return true;
	}

}
