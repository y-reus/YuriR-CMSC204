package application;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Graph implements GraphInterface<Town, Road> {

	private Map<Town, List<Road>> adjacencyList;
	private Set<Town> vertices;
	private Map<Town, Town> prevTown;
	private Map<Town, Integer> distance;

	public Graph() {

		adjacencyList = new HashMap<>();
		vertices = new HashSet<>();
		prevTown = new HashMap<>();
		distance = new HashMap<>();
	}

	@Override
	public Road getEdge(Town sourceVertex, Town destinationVertex) {

		if (!adjacencyList.containsKey(sourceVertex)) { // return null if road doesn't connect to the town

			return null;
		}

		for (Road road : adjacencyList.get(sourceVertex)) { // finds the edge then returns it

			if ((road.getSource().equals(sourceVertex) && road.getDestination().equals(destinationVertex))
					|| (road.getSource().equals(destinationVertex) && road.getDestination().equals(sourceVertex))) {

				if (road.getSource().equals(destinationVertex)) {
					
					return new Road(road.getDestination(), road.getSource(), road.getWeight(), road.getName());
				} else {
				
				return road;
				}
			}
		}

		return null;
	}

	@Override
	public Road addEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {

		if (!containsVertex(sourceVertex) || !containsVertex(destinationVertex)) { // return null if town doesn't exist

			return null;
		}

		Road road = new Road(sourceVertex, destinationVertex, weight, description);

		if (!adjacencyList.containsKey(sourceVertex)) { // add road to source list

			adjacencyList.put(sourceVertex, new ArrayList<>());
		}

		adjacencyList.get(sourceVertex).add(road);

		if (!adjacencyList.containsKey(destinationVertex)) { // add road to destination list

			adjacencyList.put(destinationVertex, new ArrayList<>());
		}

		adjacencyList.get(destinationVertex).add(road);

		return road;
	}

	@Override
	public boolean addVertex(Town v) { // adds town vertex

		if (v == null || vertices.contains(v)) {

			return false;
		}

		vertices.add(v);
		adjacencyList.put(v, new ArrayList<>());

		return true;
	}

	@Override
	public boolean containsEdge(Town sourceVertex, Town destinationVertex) { // returns if road exists between two towns

		return getEdge(sourceVertex, destinationVertex) != null;
	}

	@Override
	public boolean containsVertex(Town v) { // returns if town exists

		return vertices.contains(v);
	}

	@Override
	public Set<Road> edgeSet() { // returns a set of all roads

		Set<Road> allRoads = new HashSet<>();

		for (List<Road> roads : adjacencyList.values()) {

			allRoads.addAll(roads);
		}

		return allRoads;
	}

	@Override
	public Set<Road> edgesOf(Town vertex) { // returns all roads connected to a town

		if (!adjacencyList.containsKey(vertex)) {

			return new HashSet<>();
		}

		return new HashSet<>(adjacencyList.get(vertex));
	}

	@Override
	public Road removeEdge(Town sourceVertex, Town destinationVertex, int weight, String description) {

		if (!adjacencyList.containsKey(sourceVertex)) {

			return null;
		}

		List<Road> sourceList = adjacencyList.get(sourceVertex);
		Iterator<Road> iterator = sourceList.iterator();

		while (iterator.hasNext()) {

			Road road = iterator.next();

			if ((road.getSource().equals(sourceVertex) && road.getDestination().equals(destinationVertex)
					|| road.getSource().equals(destinationVertex) && road.getDestination().equals(sourceVertex))
					&& road.getWeight() == weight && road.getName().equals(description)) {

				iterator.remove(); // remove from source list
				adjacencyList.get(destinationVertex).remove(road); // remove from destination list

				return road;
			}
		}

		return null;
	}

	@Override
	public boolean removeVertex(Town v) { 

		if (!vertices.remove(v)) {

			return false;
		}

		adjacencyList.remove(v); // remove town from list

		for (List<Road> roadList : adjacencyList.values()) { // remove all roads connected to town

			Iterator<Road> iterator = roadList.iterator();

			while (iterator.hasNext()) {

				Road road = iterator.next();

				if (road.getSource().equals(v) || road.getDestination().equals(v)) {

					iterator.remove();
				}
			}
		}

		return true;
	}

	@Override
	public Set<Town> vertexSet() { // return all towns

		return new HashSet<>(vertices);
	}

	@Override
	public ArrayList<String> shortestPath(Town sourceVertex, Town destinationVertex) {

		dijkstraShortestPath(sourceVertex);

		ArrayList<String> path = new ArrayList<>();

		if (!distance.containsKey(destinationVertex) || distance.get(destinationVertex) == Integer.MAX_VALUE) {

			return path;
		}

		Town current = destinationVertex;

		while (!current.equals(sourceVertex)) {

			Town previous = prevTown.get(current);

			if (previous == null) {

				break;
			}

			Road road = getEdge(previous, current);
			path.add(0, previous.getName() + " via " + road.getName() + " to " + current.getName() + " "
					+ road.getWeight() + " mi");
			current = previous;
		}

		return path;
	}

	@Override
	public void dijkstraShortestPath(Town sourceVertex) {

		distance.clear();
		prevTown.clear();

		Set<Town> visited = new HashSet<>();

		for (Town town : vertices) {

			distance.put(town, Integer.MAX_VALUE);
			prevTown.put(town, null);
		}
		
		distance.put(sourceVertex, 0);

		while (visited.size() < vertices.size()) {

			Town current = null;
			int minDistance = Integer.MAX_VALUE;

			for (Town town : vertices) {

				if (!visited.contains(town) && distance.get(town) < minDistance) {
					
					minDistance = distance.get(town);
					current = town;
				}
			}

			if (current == null) {

				break;
			}

			visited.add(current);

			for (Road road : adjacencyList.get(current)) {

				Town neighbor = road.getDestination().equals(current) ? road.getSource() : road.getDestination();

				if (!visited.contains(neighbor)) {

					int newDist = distance.get(current) + road.getWeight();

					if (newDist < distance.get(neighbor)) {

						distance.put(neighbor, newDist);
						prevTown.put(neighbor, current);
					}
				}
			}
		}
	}

}
