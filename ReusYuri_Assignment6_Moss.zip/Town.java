package application;

import java.util.Objects;

public class Town implements Comparable<Town> {

	private String name;
	
	public Town(String name) {
		
		this.name = name;
	}
	
	public Town(Town templateTown) {
		
	}
	
	public String getName() {
		
		return name;
	}
	
	public int compareTo(Town o) {
		
		return name.compareTo(o.name);
	}
	
	@Override
	public String toString() {
		
		return name;
	}
	
	public int hashCode() {
		
		return Objects.hash(name);
	}
	
	public boolean equals(Object t) {
		
		if(t instanceof Town) {
			
			Town otherTown = (Town) t;
			return name.equals(otherTown.name);
		}
		
		return false;
	}
}
