package application;

public class Road implements Comparable<Road> {
	
	private String name;
	private Town destination;
	private Town source;
	private int weight;

	public Road(Town source, Town destination, int weight, String name) {
		
		this.source = source;
		this.destination = destination;
		this.weight = weight;
		this.name = name;
	}
	
	public Road(Town source, Town destination, String name) {
		
		this.source = source;
		this.destination = destination;
		this.weight = 1;
		this.name = name;
	}
	
	public boolean contains(Town town) {
		
		return source.equals(town) || destination.equals(town);
	}
	
	@Override
	public String toString() {
		
		return name + source.getName() + destination.getName() + weight;
	}
	
	public String getName() {
		
		return name;
	}
	
	public Town getDestination() {
		
		return destination;
	}
	
	public Town getSource() {
		
		return source;
	}
	
	public int compareTo(Road o) {
		
		return name.compareTo(o.name);
	}
	
	public int getWeight() {
		
		return weight;
	}
	
	public boolean equals(Object r) {
		
		if (!(r instanceof Road)) {
			
			return false;
		}
		
		Road other = (Road) r;
		
		return source.equals(other.source) && destination.equals(other.destination) && name.equals(other.name);
	}
}
