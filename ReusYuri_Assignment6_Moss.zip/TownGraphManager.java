package application;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TownGraphManager implements TownGraphManagerInterface{

	private Map<String, Town> towns;
	private Map<String, ArrayList<Road>> roads;
	
	public TownGraphManager() {
		
		towns = new HashMap<>();
		roads = new HashMap<>();
	}

	@Override
	public boolean addRoad(String town1, String town2, int weight, String roadName) {

		if (!towns.containsKey(town1) || !towns.containsKey(town2)) { // checks if towns exist

			return false;
		}

		Road newRoad = new Road(towns.get(town1), towns.get(town2), weight, roadName);

		if (!roads.containsKey(town1)) { // add road to list

			roads.put(town1, new ArrayList<Road>());
		}

		roads.get(town1).add(newRoad);

		if (!roads.containsKey(town2)) { // add road to list

			roads.put(town2, new ArrayList<Road>());
		}

		roads.get(town2).add(newRoad);

		return true;
	}

	@Override
	public String getRoad(String town1, String town2) {

		if (!roads.containsKey(town1) || !roads.containsKey(town2)) {

			return null;
		}

		ArrayList<Road> town1R = roads.get(town1);

		for (int i = 0; i < town1R.size(); i++) {

			Road road = town1R.get(i);

			if ((road.getSource().getName().equals(town1) && road.getDestination().getName().equals(town2))
					|| (road.getSource().getName().equals(town2) && road.getDestination().getName().equals(town1))) {

				return road.getName(); // return name of road between two towns
			}
		}

		return null;
	}

	@Override
	public boolean addTown(String v) {

		if (towns.containsKey(v)) { //town already exists
			
			return false;
		}
		
		towns.put(v, new Town(v)); // make new town and add it
		roads.put(v, new ArrayList<Road>()); // initialize road for the town
		
		return true;
	}

	@Override
	public Town getTown(String name) {

		return towns.get(name);
	}

	@Override
	public boolean containsTown(String v) {

		return towns.containsKey(v);
	}

	@Override
	public boolean containsRoadConnection(String town1, String town2) {

		if (!roads.containsKey(town1) || !roads.containsKey(town2)) {

			return false;
		}

		ArrayList<Road> town1R = roads.get(town1);

		for (int i = 0; i < town1R.size(); i++) { // go through all the roads in town 1

			Road road = town1R.get(i);

			if ((road.getSource().getName().equals(town1) && road.getDestination().getName().equals(town2))
					|| (road.getSource().getName().equals(town2) && road.getDestination().getName().equals(town1))) {
				
				return true; // if there's a road that connects town1 and town2 return true
			}
		}

		return false;
	}

	@Override
	public ArrayList<String> allRoads() {

		ArrayList<String> roadList = new ArrayList<>();
		
		for (ArrayList<Road> townRoads : roads.values()) {
			
			for (Road road : townRoads) { // add all road names to list
				
				if (!roadList.contains(road.getName())) {
					
					roadList.add(road.getName());
				}
			}
		}
		
		return roadList;
	}

	@Override
	public boolean deleteRoadConnection(String town1, String town2, String road) {

		if (!roads.containsKey(town1) || !roads.containsKey(town2)) {

			return false;
		}

		ArrayList<Road> town1R = roads.get(town1);
		ArrayList<Road> town2R = roads.get(town2);

		 for (int i = 0; i < town1R.size(); i++) { // look trough roads in town1 and remove it if found
			 
		        Road roadObj = town1R.get(i);
		        
		        if (roadObj.getName().equals(road)) {
		        	
		            town1R.remove(i);
		            break;
		        }
		    }

		    for (int i = 0; i < town2R.size(); i++) { // look trough roads in town2 and remove it if found
		    	
		        Road roadObj = town2R.get(i);
		        
		        if (roadObj.getName().equals(road)) {
		        	
		            town2R.remove(i);
		            break;
		        }
		    }

		return true;
	}

	@Override
	public boolean deleteTown(String v) {

		if (!towns.containsKey(v)) {
			
			return false;
		}
		
		towns.remove(v);
		
		for (String townName : towns.keySet()) { // look through all towns and roads

			
			ArrayList<Road> townRoads = roads.get(townName);
			
			for (int i = 0; i < townRoads.size(); i++) {
				
				Road road = townRoads.get(i);
				
				if (road.getSource().getName().equals(v) || road.getDestination().getName().equals(v)) { // remove road if the town is the source or destination
					
					townRoads.remove(i);
					i--;
				}
			}
		}
		
		roads.remove(v);
		
		return true;
	}

	@Override
	public ArrayList<String> allTowns() {

		ArrayList<String> townList = new ArrayList<>();
		
		for (String town : towns.keySet()) { // add all towns to list
			
			townList.add(town);
		}
		
		return townList;
	}

	@Override
	public ArrayList<String> getPath(String town1, String town2) {
		
		ArrayList<String> path = new ArrayList<>();
		
		return path;
	}

}
