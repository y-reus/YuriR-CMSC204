package application;

public class NoUpperAlphaException extends Exception{

	public NoUpperAlphaException(String message) {
		
		super(message);
	}
}
