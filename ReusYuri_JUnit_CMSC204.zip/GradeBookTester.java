package cmsc204_GradeBook;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class GradeBookTester {

	
	private GradeBook GB1;
	private GradeBook GB2;
	
	@BeforeEach
	public void setUp() {
		
		GB1 = new GradeBook(5);
		GB2 = new GradeBook(5);
		
		GB1.addScore(50.0);
		GB1.addScore(75.0);
		
		GB2.addScore(82.0);
		GB2.addScore(88.0);
		GB2.addScore(43.0);
	}
	
	@AfterEach
	public void tearDown() {
		
		GB1 = null;
		GB2 = null;
	}
	
	@Test
	public void addScoreTest() {
		
		assertTrue(GB1.toString().equals("50.0 75.0 "));
		assertTrue(GB2.toString().equals("82.0 88.0 43.0 "));
	}
	
	@Test
	public void sumTest() {
		
		assertEquals(125, GB1.sum(),.001);
		assertEquals(213, GB2.sum(),.001);
	}
	
	@Test
	public void minimumTest() {
		
		assertEquals(50.0, GB1.minimum(),.001);
		assertEquals(43.0, GB2.minimum(),.001);
	}
	
	@Test
	public void finalScoreTest() {
		
		assertEquals(75.0, GB1.finalScore(), .001);
		assertEquals(170.0, GB2.finalScore(), .001);
	}
}
